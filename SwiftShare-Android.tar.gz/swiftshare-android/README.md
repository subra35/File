# SwiftShare — WiFi Direct File Transfer App

Fast, offline, peer-to-peer file transfer between Android devices using WiFi Direct.
No internet. No accounts. No ads.

---

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34 (compileSdk / targetSdk)
- Minimum SDK: Android 9 (API 28)
- Two Android phones with WiFi Direct support

---

## How to Open in Android Studio

1. Unzip the project folder
2. Open Android Studio → **File → Open** → select the `swiftshare-android/` folder
3. Wait for Gradle sync to complete (first sync downloads dependencies — requires internet)
4. Connect your Android device with USB debugging enabled
5. Click **Run** (▶) to build and install

---

## How to Use

### Sending Files
1. Open SwiftShare on both devices
2. On the **sender** device: tap **SEND**, pick one or more files
3. A list of nearby devices appears — tap the **receiver** device name
4. Watch the real-time progress: speed, %, and ETA

### Receiving Files
1. Open SwiftShare on the receiver device
2. Tap **RECEIVE** — the device becomes discoverable
3. When the sender connects, the transfer starts automatically
4. Files are saved to the **Downloads** folder
5. A notification appears when each file is saved — tap to open

---

## Architecture

```
com.swiftshare/
├── MainActivity.kt               — Single-activity host with nav controller
├── ui/
│   ├── HomeFragment.kt           — Send / Receive entry point
│   ├── DeviceListFragment.kt     — Peer discovery list (send flow)
│   ├── TransferFragment.kt       — Live progress during transfer
│   └── HistoryFragment.kt        — Room-backed transfer history
├── wifi/
│   ├── WiFiDirectManager.kt      — WifiP2pManager wrapper (coroutine-based)
│   └── WiFiDirectBroadcastReceiver.kt — System WiFi Direct events
├── transfer/
│   ├── FileSender.kt             — TCP sender (ServerSocket or client Socket)
│   ├── FileReceiver.kt           — TCP receiver (ServerSocket or client Socket)
│   └── TransferMetadata.kt       — Progress data classes + byte formatting
├── db/
│   ├── AppDatabase.kt            — Room singleton
│   ├── TransferDao.kt            — Queries (LiveData)
│   └── TransferHistory.kt        — Entity
└── viewmodel/
    └── TransferViewModel.kt      — Central state, orchestrates WiFi + transfer
```

---

## Technical Details

| Detail | Value |
|---|---|
| Transfer protocol | TCP socket over WiFi Direct |
| Port | 8888 |
| Chunk size | 65,536 bytes (64 KB) |
| Stream buffer | 1,048,576 bytes (1 MB) |
| Group Owner | Runs ServerSocket |
| Client device | Connects as Socket |
| File save location | MediaStore Downloads (API 29+) or `/storage/emulated/0/Download/` |
| Multiple files | Count header → per-file name+size header → raw bytes |
| Background thread | Kotlin coroutines `Dispatchers.IO` |

---

## Permissions

| Permission | Reason |
|---|---|
| `ACCESS_FINE_LOCATION` | Required by Android for WiFi Direct peer discovery |
| `NEARBY_WIFI_DEVICES` | Android 13+ replacement for location in WiFi Direct |
| `CHANGE_WIFI_STATE` | Needed to connect to peers |
| `READ_MEDIA_*` / `READ_EXTERNAL_STORAGE` | File picker access |
| `WAKE_LOCK` | Keep screen on during transfer |
| `VIBRATE` | Haptic feedback on transfer complete |
| `POST_NOTIFICATIONS` | File received notification (Android 13+) |

---

## Notes

- WiFi Direct does **not** require an internet connection or a WiFi router
- Both devices must have SwiftShare open during the transfer
- The **Group Owner** (determined by Android automatically) always runs the ServerSocket
- Transfer speed depends on device hardware and WiFi Direct radio; typical real-world speeds are 20–80 MB/s
