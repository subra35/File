# SwiftShare ProGuard Rules

# Keep application class names
-keep class com.swiftshare.** { *; }

# Room database
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keep @androidx.room.Dao class *

# Kotlin coroutines
-keepclassmembernames class kotlinx.** {
    volatile <fields>;
}

# Navigation
-keepnames class androidx.navigation.fragment.NavHostFragment
