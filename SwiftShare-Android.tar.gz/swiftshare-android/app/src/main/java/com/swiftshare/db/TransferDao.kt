package com.swiftshare.db

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface TransferDao {

    @Query("SELECT * FROM transfer_history ORDER BY timestamp DESC")
    fun getAllHistory(): LiveData<List<TransferHistory>>

    @Query("SELECT * FROM transfer_history WHERE direction = 'SENT' ORDER BY timestamp DESC")
    fun getSentHistory(): LiveData<List<TransferHistory>>

    @Query("SELECT * FROM transfer_history WHERE direction = 'RECEIVED' ORDER BY timestamp DESC")
    fun getReceivedHistory(): LiveData<List<TransferHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(history: TransferHistory): Long

    @Delete
    suspend fun delete(history: TransferHistory)

    @Query("DELETE FROM transfer_history")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM transfer_history")
    suspend fun getCount(): Int
}
