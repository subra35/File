package com.swiftshare.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfer_history")
data class TransferHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val fileSize: Long,
    val direction: String, // "SENT" or "RECEIVED"
    val remotePeerName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMs: Long = 0,
    val filePath: String = ""
) {
    val isReceived: Boolean get() = direction == "RECEIVED"
    val isSent: Boolean get() = direction == "SENT"
}
