package com.swiftshare.transfer

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import com.swiftshare.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

data class ReceivedFile(val name: String, val size: Long, val uri: Uri?)

class FileReceiver(
    private val context: Context,
    private val onProgress: (TransferProgress) -> Unit,
    private val onFileReceived: (ReceivedFile) -> Unit
) {
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null

    /**
     * Called when this device is the Group Owner (server role during receive).
     */
    suspend fun receiveAsServer() = withContext(Dispatchers.IO) {
        try {
            serverSocket = ServerSocket(TRANSFER_PORT)
            clientSocket = serverSocket!!.accept()
            receiveFiles()
        } finally {
            closeAll()
        }
    }

    /**
     * Called when the sender is the group owner; this device connects as client.
     */
    suspend fun receiveAsClient(hostAddress: String) = withContext(Dispatchers.IO) {
        try {
            clientSocket = Socket()
            clientSocket!!.connect(InetSocketAddress(hostAddress, TRANSFER_PORT), 10_000)
            receiveFiles()
        } finally {
            closeAll()
        }
    }

    private suspend fun receiveFiles() = withContext(Dispatchers.IO) {
        val socket = clientSocket ?: return@withContext
        val bis = BufferedInputStream(socket.getInputStream(), BUFFER_SIZE)
        val dis = DataInputStream(bis)

        val fileCount = dis.readInt()

        repeat(fileCount) { index ->
            val fileName = dis.readUTF()
            val fileSize = dis.readLong()

            val outputStream: OutputStream?
            val savedUri: Uri?

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                savedUri = context.contentResolver.insert(collection, values)
                outputStream = savedUri?.let { context.contentResolver.openOutputStream(it) }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                downloadsDir.mkdirs()
                val file = java.io.File(downloadsDir, fileName)
                savedUri = Uri.fromFile(file)
                outputStream = file.outputStream()
            }

            outputStream?.buffered(BUFFER_SIZE)?.use { bos ->
                val buffer = ByteArray(CHUNK_SIZE)
                var bytesReceived = 0L
                var lastReportTime = System.currentTimeMillis()
                var lastReportBytes = 0L

                while (bytesReceived < fileSize && isActive) {
                    val toRead = minOf(buffer.size.toLong(), fileSize - bytesReceived).toInt()
                    val bytesRead = dis.read(buffer, 0, toRead)
                    if (bytesRead == -1) break
                    bos.write(buffer, 0, bytesRead)
                    bytesReceived += bytesRead

                    val now = System.currentTimeMillis()
                    val elapsed = now - lastReportTime
                    if (elapsed >= 200) {
                        val speed = ((bytesReceived - lastReportBytes) * 1000L) / elapsed
                        lastReportTime = now
                        lastReportBytes = bytesReceived
                        withContext(Dispatchers.Main) {
                            onProgress(
                                TransferProgress(
                                    fileName = fileName,
                                    fileIndex = index,
                                    totalFiles = fileCount,
                                    bytesTransferred = bytesReceived,
                                    totalBytes = fileSize,
                                    speedBytesPerSec = speed
                                )
                            )
                        }
                    }
                }
            }

            // Mark file as complete in MediaStore (Android 10+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && savedUri != null) {
                val update = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                context.contentResolver.update(savedUri, update, null, null)
            }

            val received = ReceivedFile(fileName, fileSize, savedUri)
            withContext(Dispatchers.Main) {
                onFileReceived(received)
                onProgress(
                    TransferProgress(
                        fileName = fileName,
                        fileIndex = index,
                        totalFiles = fileCount,
                        bytesTransferred = fileSize,
                        totalBytes = fileSize,
                        speedBytesPerSec = 0,
                        isComplete = index == fileCount - 1
                    )
                )
            }
            showNotification(fileName, savedUri)
        }
    }

    private fun showNotification(fileName: String, uri: Uri?) {
        val channelId = "swiftshare_transfer"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "File Transfers",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            nm.createNotificationChannel(channel)
        }

        val openIntent = if (uri != null) {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            PendingIntent.getActivity(
                context, 0, intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        } else null

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("File received")
            .setContentText(fileName)
            .setAutoCancel(true)
            .apply { if (openIntent != null) setContentIntent(openIntent) }
            .build()

        nm.notify(System.currentTimeMillis().toInt(), notification)
    }

    fun cancel() {
        closeAll()
    }

    private fun closeAll() {
        try { clientSocket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        clientSocket = null
        serverSocket = null
    }
}
