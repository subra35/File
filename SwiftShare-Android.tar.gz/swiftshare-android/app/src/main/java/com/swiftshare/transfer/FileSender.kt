package com.swiftshare.transfer

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

const val TRANSFER_PORT = 8888
const val CHUNK_SIZE = 65536
const val BUFFER_SIZE = 1_048_576

class FileSender(
    private val contentResolver: ContentResolver,
    private val onProgress: (TransferProgress) -> Unit
) {
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null

    /**
     * Called when this device is the Group Owner (server).
     * Opens a ServerSocket, waits for the receiver to connect, then sends files.
     */
    suspend fun sendAsServer(uris: List<Uri>) = withContext(Dispatchers.IO) {
        try {
            serverSocket = ServerSocket(TRANSFER_PORT)
            clientSocket = serverSocket!!.accept()
            sendFiles(uris)
        } finally {
            closeAll()
        }
    }

    /**
     * Called when this device is the client connecting to a group owner receiver.
     */
    suspend fun sendAsClient(hostAddress: String, uris: List<Uri>) = withContext(Dispatchers.IO) {
        try {
            clientSocket = Socket()
            clientSocket!!.connect(InetSocketAddress(hostAddress, TRANSFER_PORT), 10_000)
            sendFiles(uris)
        } finally {
            closeAll()
        }
    }

    private suspend fun sendFiles(uris: List<Uri>) = withContext(Dispatchers.IO) {
        val socket = clientSocket ?: return@withContext
        val bos = BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE)
        val dos = DataOutputStream(bos)

        // Send total file count
        dos.writeInt(uris.size)
        dos.flush()

        uris.forEachIndexed { index, uri ->
            val meta = getFileMetadata(uri)
            // Send file header: name length + name + size
            dos.writeUTF(meta.name)
            dos.writeLong(meta.size)
            dos.flush()

            // Send file bytes
            contentResolver.openInputStream(uri)?.use { inputStream ->
                val buffer = ByteArray(CHUNK_SIZE)
                var bytesSent = 0L
                var bytesRead: Int
                val startTime = System.currentTimeMillis()
                var lastReportTime = startTime
                var lastReportBytes = 0L

                while (isActive) {
                    bytesRead = inputStream.read(buffer)
                    if (bytesRead == -1) break
                    dos.write(buffer, 0, bytesRead)
                    bytesSent += bytesRead

                    val now = System.currentTimeMillis()
                    val elapsed = now - lastReportTime
                    if (elapsed >= 200) {
                        val speed = ((bytesSent - lastReportBytes) * 1000L) / elapsed
                        lastReportTime = now
                        lastReportBytes = bytesSent
                        withContext(Dispatchers.Main) {
                            onProgress(
                                TransferProgress(
                                    fileName = meta.name,
                                    fileIndex = index,
                                    totalFiles = uris.size,
                                    bytesTransferred = bytesSent,
                                    totalBytes = meta.size,
                                    speedBytesPerSec = speed
                                )
                            )
                        }
                    }
                }
                dos.flush()
                // Final progress report
                withContext(Dispatchers.Main) {
                    onProgress(
                        TransferProgress(
                            fileName = meta.name,
                            fileIndex = index,
                            totalFiles = uris.size,
                            bytesTransferred = bytesSent,
                            totalBytes = meta.size,
                            speedBytesPerSec = 0,
                            isComplete = index == uris.size - 1
                        )
                    )
                }
            }
        }
        bos.flush()
    }

    private fun getFileMetadata(uri: Uri): FileMetadata {
        var name = "file_${System.currentTimeMillis()}"
        var size = 0L

        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
            }
        }

        if (size == 0L) {
            contentResolver.openFileDescriptor(uri, "r")?.use {
                size = it.statSize
            }
        }

        return FileMetadata(name = name, size = size)
    }

    fun cancel() {
        closeAll()
    }

    private fun closeAll() {
        try { clientSocket?.close() } catch (_: Exception) {}
        try { serverSocket?.close() } catch (_: Exception) {}
        clientSocket = null
        serverSocket = null
    }
}
