package com.swiftshare.transfer

data class FileMetadata(
    val name: String,
    val size: Long,
    val mimeType: String = "application/octet-stream"
)

data class TransferProgress(
    val fileName: String,
    val fileIndex: Int,
    val totalFiles: Int,
    val bytesTransferred: Long,
    val totalBytes: Long,
    val speedBytesPerSec: Long,
    val isComplete: Boolean = false,
    val error: String? = null
) {
    val percentage: Int
        get() = if (totalBytes > 0) ((bytesTransferred * 100) / totalBytes).toInt() else 0

    val speedMbps: Double
        get() = speedBytesPerSec / (1024.0 * 1024.0)

    val estimatedSecondsRemaining: Long
        get() {
            if (speedBytesPerSec <= 0) return -1
            val remaining = totalBytes - bytesTransferred
            return remaining / speedBytesPerSec
        }

    val formattedSpeed: String
        get() = String.format("%.2f MB/s", speedMbps)

    val formattedEta: String
        get() {
            val secs = estimatedSecondsRemaining
            return when {
                secs < 0 -> "Calculating..."
                secs < 60 -> "${secs}s remaining"
                else -> "${secs / 60}m ${secs % 60}s remaining"
            }
        }

    val formattedSize: String
        get() = formatBytes(totalBytes)

    val formattedTransferred: String
        get() = formatBytes(bytesTransferred)
}

fun formatBytes(bytes: Long): String {
    return when {
        bytes >= 1_073_741_824L -> String.format("%.2f GB", bytes / 1_073_741_824.0)
        bytes >= 1_048_576L -> String.format("%.2f MB", bytes / 1_048_576.0)
        bytes >= 1_024L -> String.format("%.1f KB", bytes / 1_024.0)
        else -> "$bytes B"
    }
}
