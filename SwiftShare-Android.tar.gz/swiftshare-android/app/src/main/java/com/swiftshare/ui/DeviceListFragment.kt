package com.swiftshare.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.swiftshare.R
import com.swiftshare.databinding.FragmentDeviceListBinding
import com.swiftshare.viewmodel.ConnectionState
import com.swiftshare.viewmodel.TransferViewModel
import android.net.wifi.p2p.WifiP2pDevice

class DeviceListFragment : Fragment() {

    private var _binding: FragmentDeviceListBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransferViewModel by activityViewModels()
    private lateinit var adapter: DeviceAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDeviceListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = DeviceAdapter { device ->
            viewModel.connectToDevice(device)
        }

        binding.recyclerDevices.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@DeviceListFragment.adapter
            addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        }

        viewModel.peers.observe(viewLifecycleOwner) { peers ->
            adapter.submitList(peers)
            binding.tvNoPeers.visibility = if (peers.isEmpty()) View.VISIBLE else View.GONE
        }

        viewModel.connectionState.observe(viewLifecycleOwner) { state ->
            when (state) {
                ConnectionState.DISCOVERING -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.tvStatus.text = "Scanning for nearby devices..."
                }
                ConnectionState.CONNECTING -> {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.tvStatus.text = "Connecting..."
                }
                ConnectionState.CONNECTED -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvStatus.text = "Connected! Starting transfer..."
                    findNavController().navigate(R.id.action_deviceList_to_transfer)
                }
                ConnectionState.DISCONNECTED -> {
                    binding.progressBar.visibility = View.GONE
                    binding.tvStatus.text = "Disconnected"
                }
            }
        }

        viewModel.statusMessage.observe(viewLifecycleOwner) { msg ->
            if (msg.isNotEmpty()) binding.tvStatus.text = msg
        }

        binding.btnRefresh.setOnClickListener {
            viewModel.startSendMode(emptyList())
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class DeviceAdapter(
    private val onDeviceClick: (WifiP2pDevice) -> Unit
) : RecyclerView.Adapter<DeviceAdapter.DeviceViewHolder>() {

    private var devices: List<WifiP2pDevice> = emptyList()

    fun submitList(list: List<WifiP2pDevice>) {
        devices = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DeviceViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_device, parent, false)
        return DeviceViewHolder(view)
    }

    override fun onBindViewHolder(holder: DeviceViewHolder, position: Int) {
        holder.bind(devices[position])
    }

    override fun getItemCount() = devices.size

    inner class DeviceViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tv_device_name)
        private val tvAddress: TextView = itemView.findViewById(R.id.tv_device_address)
        private val tvStatus: TextView = itemView.findViewById(R.id.tv_device_status)

        fun bind(device: WifiP2pDevice) {
            tvName.text = device.deviceName.ifBlank { "Unknown Device" }
            tvAddress.text = device.deviceAddress
            tvStatus.text = when (device.status) {
                WifiP2pDevice.CONNECTED -> "Connected"
                WifiP2pDevice.INVITED -> "Invited"
                WifiP2pDevice.FAILED -> "Failed"
                WifiP2pDevice.AVAILABLE -> "Available"
                WifiP2pDevice.UNAVAILABLE -> "Unavailable"
                else -> "Unknown"
            }
            itemView.setOnClickListener { onDeviceClick(device) }
        }
    }
}
