package com.swiftshare.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.swiftshare.R
import com.swiftshare.databinding.FragmentHistoryBinding
import com.swiftshare.db.TransferHistory
import com.swiftshare.transfer.formatBytes
import com.swiftshare.viewmodel.TransferViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransferViewModel by activityViewModels()
    private lateinit var adapter: HistoryAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        adapter = HistoryAdapter()
        binding.recyclerHistory.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@HistoryFragment.adapter
            addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        }

        viewModel.transferHistory.observe(viewLifecycleOwner) { history ->
            adapter.submitList(history)
            binding.tvEmpty.visibility = if (history.isEmpty()) View.VISIBLE else View.GONE
        }

        binding.btnClearHistory.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Clear History")
                .setMessage("Delete all transfer history?")
                .setPositiveButton("Delete") { _, _ -> viewModel.clearHistory() }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class HistoryAdapter : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    private var items: List<TransferHistory> = emptyList()
    private val dateFormat = SimpleDateFormat("MMM d, yyyy  hh:mm a", Locale.getDefault())

    fun submitList(list: List<TransferHistory>) {
        items = list
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount() = items.size

    inner class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvFileName: TextView = itemView.findViewById(R.id.tv_history_filename)
        private val tvDirection: TextView = itemView.findViewById(R.id.tv_history_direction)
        private val tvSize: TextView = itemView.findViewById(R.id.tv_history_size)
        private val tvDate: TextView = itemView.findViewById(R.id.tv_history_date)
        private val tvPeer: TextView = itemView.findViewById(R.id.tv_history_peer)

        fun bind(item: TransferHistory) {
            tvFileName.text = item.fileName
            tvDirection.text = if (item.isReceived) "⬇ Received" else "⬆ Sent"
            tvDirection.setTextColor(
                if (item.isReceived)
                    itemView.context.getColor(R.color.green)
                else
                    itemView.context.getColor(R.color.accent_blue)
            )
            tvSize.text = formatBytes(item.fileSize)
            tvDate.text = dateFormat.format(Date(item.timestamp))
            tvPeer.text = if (item.isReceived)
                "From: ${item.remotePeerName}" else "To: ${item.remotePeerName}"
        }
    }
}
