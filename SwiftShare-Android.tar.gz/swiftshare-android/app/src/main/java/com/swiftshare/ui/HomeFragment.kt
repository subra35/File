package com.swiftshare.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.swiftshare.R
import com.swiftshare.databinding.FragmentHomeBinding
import com.swiftshare.viewmodel.AppMode
import com.swiftshare.viewmodel.TransferViewModel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransferViewModel by activityViewModels()

    private val filePicker = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        if (uris.isNotEmpty()) {
            viewModel.startSendMode(uris)
            findNavController().navigate(R.id.action_home_to_deviceList)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.initWifiDirect(requireContext())

        viewModel.thisDeviceName.observe(viewLifecycleOwner) { name ->
            binding.tvDeviceName.text = name
        }

        viewModel.wifiEnabled.observe(viewLifecycleOwner) { enabled ->
            binding.tvWifiStatus.text = if (enabled) "WiFi Direct: ON" else "WiFi Direct: OFF"
            binding.tvWifiStatus.setTextColor(
                if (enabled)
                    requireContext().getColor(R.color.green)
                else
                    requireContext().getColor(R.color.red)
            )
            binding.btnSend.isEnabled = enabled
            binding.btnReceive.isEnabled = enabled
        }

        binding.btnSend.setOnClickListener {
            filePicker.launch("*/*")
        }

        binding.btnReceive.setOnClickListener {
            viewModel.startReceiveMode()
            findNavController().navigate(R.id.action_home_to_transfer)
        }

        binding.btnHistory.setOnClickListener {
            findNavController().navigate(R.id.action_home_to_history)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
