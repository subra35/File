package com.swiftshare.ui

import android.os.Bundle
import android.os.PowerManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.swiftshare.databinding.FragmentTransferBinding
import com.swiftshare.viewmodel.AppMode
import com.swiftshare.viewmodel.TransferViewModel

class TransferFragment : Fragment() {

    private var _binding: FragmentTransferBinding? = null
    private val binding get() = _binding!!
    private val viewModel: TransferViewModel by activityViewModels()
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTransferBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        acquireWakeLock()

        viewModel.appMode.observe(viewLifecycleOwner) { mode ->
            binding.tvMode.text = when (mode) {
                AppMode.SENDING -> "Sending Files"
                AppMode.RECEIVING -> "Receiving Files"
                else -> "Transfer"
            }
        }

        viewModel.statusMessage.observe(viewLifecycleOwner) { msg ->
            if (viewModel.progress.value == null && msg.isNotEmpty()) {
                binding.tvStatus.text = msg
            }
        }

        viewModel.progress.observe(viewLifecycleOwner) { progress ->
            if (progress == null) {
                binding.groupProgress.visibility = View.GONE
                binding.tvStatus.text = "Waiting for connection..."
                return@observe
            }

            if (progress.error != null) {
                binding.tvStatus.text = "Error: ${progress.error}"
                binding.progressBar.visibility = View.GONE
                return@observe
            }

            binding.groupProgress.visibility = View.VISIBLE
            binding.tvFileName.text = progress.fileName
            binding.tvFileCounter.text = "File ${progress.fileIndex + 1} of ${progress.totalFiles}"
            binding.tvSpeed.text = progress.formattedSpeed
            binding.tvEta.text = progress.formattedEta
            binding.tvBytes.text = "${progress.formattedTransferred} / ${progress.formattedSize}"
            binding.progressBar.progress = progress.percentage
            binding.tvPercentage.text = "${progress.percentage}%"

            if (progress.isComplete) {
                binding.tvStatus.text = if (viewModel.appMode.value == AppMode.RECEIVING)
                    "File saved to Downloads!" else "Transfer complete!"
                binding.btnCancel.text = "Done"
                releaseWakeLock()
            }
        }

        binding.btnCancel.setOnClickListener {
            viewModel.cancelTransfer()
            findNavController().popBackStack()
        }
    }

    private fun acquireWakeLock() {
        val pm = requireContext().getSystemService(android.content.Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ON_AFTER_RELEASE,
            "SwiftShare::TransferWakeLock"
        ).apply { acquire(30 * 60 * 1000L) } // 30 minute max
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
    }

    override fun onDestroyView() {
        super.onDestroyView()
        releaseWakeLock()
        _binding = null
    }
}
