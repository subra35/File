package com.swiftshare.viewmodel

import android.app.Application
import android.net.Uri
import android.net.wifi.p2p.WifiP2pDevice
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.swiftshare.db.AppDatabase
import com.swiftshare.db.TransferHistory
import com.swiftshare.transfer.FileReceiver
import com.swiftshare.transfer.FileSender
import com.swiftshare.transfer.ReceivedFile
import com.swiftshare.transfer.TransferProgress
import com.swiftshare.wifi.WiFiDirectBroadcastReceiver
import com.swiftshare.wifi.WiFiDirectManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class AppMode { IDLE, SENDING, RECEIVING }
enum class ConnectionState { DISCONNECTED, DISCOVERING, CONNECTING, CONNECTED }

class TransferViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val dao = db.transferDao()

    val transferHistory: LiveData<List<TransferHistory>> = dao.getAllHistory()

    private val _wifiEnabled = MutableLiveData(false)
    val wifiEnabled: LiveData<Boolean> = _wifiEnabled

    private val _peers = MutableLiveData<List<WifiP2pDevice>>(emptyList())
    val peers: LiveData<List<WifiP2pDevice>> = _peers

    private val _connectionState = MutableLiveData(ConnectionState.DISCONNECTED)
    val connectionState: LiveData<ConnectionState> = _connectionState

    private val _progress = MutableLiveData<TransferProgress?>()
    val progress: LiveData<TransferProgress?> = _progress

    private val _appMode = MutableLiveData(AppMode.IDLE)
    val appMode: LiveData<AppMode> = _appMode

    private val _thisDeviceName = MutableLiveData<String>("This Device")
    val thisDeviceName: LiveData<String> = _thisDeviceName

    private val _statusMessage = MutableLiveData<String>("")
    val statusMessage: LiveData<String> = _statusMessage

    private val _connectedPeerName = MutableLiveData<String>("")
    val connectedPeerName: LiveData<String> = _connectedPeerName

    private var selectedUris: List<Uri> = emptyList()
    private var groupOwnerAddress: String? = null
    private var isGroupOwner = false
    private var transferStartTime = 0L

    private var transferJob: Job? = null
    private var fileSender: FileSender? = null
    private var fileReceiver: FileReceiver? = null

    lateinit var wifiDirectManager: WiFiDirectManager

    val wifiDirectListener = object : WiFiDirectBroadcastReceiver.WiFiDirectListener {
        override fun onWifiP2pEnabled(enabled: Boolean) {
            _wifiEnabled.postValue(enabled)
            if (!enabled) _statusMessage.postValue("WiFi Direct is disabled. Please enable WiFi.")
        }

        override fun onPeersChanged(peers: List<WifiP2pDevice>) {
            _peers.postValue(peers)
        }

        override fun onConnectionChanged(connected: Boolean, groupOwnerAddress: String?) {
            if (connected) {
                this@TransferViewModel.groupOwnerAddress = groupOwnerAddress
                isGroupOwner = groupOwnerAddress == null
                _connectionState.postValue(ConnectionState.CONNECTED)
                _statusMessage.postValue(
                    if (isGroupOwner) "Connected (Group Owner)" else "Connected to group owner"
                )
                startTransfer()
            } else {
                _connectionState.postValue(ConnectionState.DISCONNECTED)
            }
        }

        override fun onThisDeviceChanged(device: WifiP2pDevice) {
            _thisDeviceName.postValue(device.deviceName)
        }
    }

    fun initWifiDirect(context: android.content.Context) {
        wifiDirectManager = WiFiDirectManager(context, wifiDirectListener)
        wifiDirectManager.registerReceiver()
    }

    fun cleanupWifiDirect() {
        wifiDirectManager.unregisterReceiver()
    }

    fun startSendMode(uris: List<Uri>) {
        selectedUris = uris
        _appMode.value = AppMode.SENDING
        _connectionState.value = ConnectionState.DISCOVERING
        _statusMessage.value = "Discovering nearby devices..."
        viewModelScope.launch {
            runCatching { wifiDirectManager.discoverPeers() }
        }
    }

    fun startReceiveMode() {
        _appMode.value = AppMode.RECEIVING
        _connectionState.value = ConnectionState.DISCOVERING
        _statusMessage.value = "Waiting for sender to connect..."
        viewModelScope.launch {
            runCatching { wifiDirectManager.discoverPeers() }
        }
    }

    fun connectToDevice(device: WifiP2pDevice) {
        _connectionState.value = ConnectionState.CONNECTING
        _connectedPeerName.value = device.deviceName
        _statusMessage.value = "Connecting to ${device.deviceName}..."
        viewModelScope.launch {
            runCatching { wifiDirectManager.connect(device) }
                .onFailure { _statusMessage.postValue("Connection failed: ${it.message}") }
        }
    }

    private fun startTransfer() {
        transferStartTime = System.currentTimeMillis()
        when (_appMode.value) {
            AppMode.SENDING -> startSending()
            AppMode.RECEIVING -> startReceiving()
            else -> {}
        }
    }

    private fun startSending() {
        val sender = FileSender(
            contentResolver = getApplication<Application>().contentResolver,
            onProgress = { progress ->
                _progress.postValue(progress)
                if (progress.isComplete) onTransferComplete(progress)
            }
        )
        fileSender = sender
        transferJob = viewModelScope.launch {
            runCatching {
                if (isGroupOwner) {
                    sender.sendAsServer(selectedUris)
                } else {
                    sender.sendAsClient(groupOwnerAddress!!, selectedUris)
                }
            }.onFailure { e ->
                _progress.postValue(
                    _progress.value?.copy(error = e.message ?: "Transfer failed")
                )
            }
        }
    }

    private fun startReceiving() {
        val receiver = FileReceiver(
            context = getApplication(),
            onProgress = { progress ->
                _progress.postValue(progress)
                if (progress.isComplete) onTransferComplete(progress)
            },
            onFileReceived = { file ->
                saveToHistory(file)
            }
        )
        fileReceiver = receiver
        transferJob = viewModelScope.launch {
            runCatching {
                if (isGroupOwner) {
                    receiver.receiveAsServer()
                } else {
                    receiver.receiveAsClient(groupOwnerAddress!!)
                }
            }.onFailure { e ->
                _progress.postValue(
                    _progress.value?.copy(error = e.message ?: "Receive failed")
                )
            }
        }
    }

    private fun onTransferComplete(progress: TransferProgress) {
        vibrate()
        val durationMs = System.currentTimeMillis() - transferStartTime
        if (_appMode.value == AppMode.SENDING) {
            selectedUris.forEach { uri ->
                val name = uri.lastPathSegment ?: "file"
                viewModelScope.launch {
                    dao.insert(
                        TransferHistory(
                            fileName = progress.fileName,
                            fileSize = progress.totalBytes,
                            direction = "SENT",
                            remotePeerName = _connectedPeerName.value ?: "Unknown",
                            durationMs = durationMs
                        )
                    )
                }
            }
        }
    }

    private fun saveToHistory(file: ReceivedFile) {
        viewModelScope.launch {
            dao.insert(
                TransferHistory(
                    fileName = file.name,
                    fileSize = file.size,
                    direction = "RECEIVED",
                    remotePeerName = _connectedPeerName.value ?: "Unknown",
                    filePath = file.uri?.toString() ?: ""
                )
            )
        }
    }

    fun cancelTransfer() {
        transferJob?.cancel()
        fileSender?.cancel()
        fileReceiver?.cancel()
        _progress.value = null
        _appMode.value = AppMode.IDLE
        _connectionState.value = ConnectionState.DISCONNECTED
        viewModelScope.launch {
            runCatching { wifiDirectManager.disconnect() }
        }
    }

    fun clearHistory() {
        viewModelScope.launch { dao.deleteAll() }
    }

    private fun vibrate() {
        val context = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(VibratorManager::class.java)
            vm?.defaultVibrator?.vibrate(
                VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val v = context.getSystemService(android.content.Context.VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v?.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v?.vibrate(300)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        runCatching { wifiDirectManager.unregisterReceiver() }
    }
}
