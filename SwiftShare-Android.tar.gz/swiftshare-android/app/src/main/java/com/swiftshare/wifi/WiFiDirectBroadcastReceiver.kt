package com.swiftshare.wifi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.NetworkInfo
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager

class WiFiDirectBroadcastReceiver(
    private val manager: WifiP2pManager,
    private val channel: WifiP2pManager.Channel,
    private val listener: WiFiDirectListener
) : BroadcastReceiver() {

    interface WiFiDirectListener {
        fun onWifiP2pEnabled(enabled: Boolean)
        fun onPeersChanged(peers: List<WifiP2pDevice>)
        fun onConnectionChanged(connected: Boolean, groupOwnerAddress: String?)
        fun onThisDeviceChanged(device: WifiP2pDevice)
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                listener.onWifiP2pEnabled(state == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
            }

            WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                manager.requestPeers(channel) { peerList ->
                    listener.onPeersChanged(peerList.deviceList.toList())
                }
            }

            WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                val networkInfo = intent.getParcelableExtra<NetworkInfo>(WifiP2pManager.EXTRA_NETWORK_INFO)
                if (networkInfo?.isConnected == true) {
                    manager.requestConnectionInfo(channel) { info ->
                        val ownerAddress = if (info.isGroupOwner) null else info.groupOwnerAddress?.hostAddress
                        listener.onConnectionChanged(true, ownerAddress)
                    }
                } else {
                    listener.onConnectionChanged(false, null)
                }
            }

            WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                val device = intent.getParcelableExtra<WifiP2pDevice>(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE)
                if (device != null) listener.onThisDeviceChanged(device)
            }
        }
    }
}
