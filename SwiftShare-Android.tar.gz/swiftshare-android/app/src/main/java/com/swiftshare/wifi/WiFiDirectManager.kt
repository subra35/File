package com.swiftshare.wifi

import android.content.Context
import android.content.IntentFilter
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class WiFiDirectManager(
    private val context: Context,
    private val listener: WiFiDirectBroadcastReceiver.WiFiDirectListener
) {
    val manager: WifiP2pManager =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager

    val channel: WifiP2pManager.Channel = manager.initialize(context, context.mainLooper, null)

    private val receiver = WiFiDirectBroadcastReceiver(manager, channel, listener)

    val intentFilter = IntentFilter().apply {
        addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
    }

    fun registerReceiver() {
        context.registerReceiver(receiver, intentFilter)
    }

    fun unregisterReceiver() {
        try {
            context.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {}
    }

    suspend fun discoverPeers() = suspendCancellableCoroutine { cont ->
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { if (cont.isActive) cont.resume(Unit) }
            override fun onFailure(reason: Int) {
                if (cont.isActive) cont.resumeWithException(
                    Exception("Peer discovery failed: reason $reason")
                )
            }
        })
    }

    suspend fun stopDiscovery() = suspendCancellableCoroutine { cont ->
        manager.stopPeerDiscovery(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { if (cont.isActive) cont.resume(Unit) }
            override fun onFailure(reason: Int) { if (cont.isActive) cont.resume(Unit) }
        })
    }

    suspend fun connect(device: WifiP2pDevice) = suspendCancellableCoroutine { cont ->
        val config = WifiP2pConfig().apply { deviceAddress = device.deviceAddress }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { if (cont.isActive) cont.resume(Unit) }
            override fun onFailure(reason: Int) {
                if (cont.isActive) cont.resumeWithException(
                    Exception("Connection failed: reason $reason")
                )
            }
        })
    }

    suspend fun disconnect() = suspendCancellableCoroutine { cont ->
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() { if (cont.isActive) cont.resume(Unit) }
            override fun onFailure(reason: Int) { if (cont.isActive) cont.resume(Unit) }
        })
    }

    suspend fun requestPeers(): List<WifiP2pDevice> = suspendCancellableCoroutine { cont ->
        manager.requestPeers(channel) { peerList ->
            if (cont.isActive) cont.resume(peerList.deviceList.toList())
        }
    }
}
